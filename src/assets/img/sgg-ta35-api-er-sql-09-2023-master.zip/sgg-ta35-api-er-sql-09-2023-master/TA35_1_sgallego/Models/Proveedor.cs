﻿using System;
using System.Collections.Generic;

namespace TA35_1_sgallego.Models;

public partial class Proveedor
{
    public string Id { get; set; } = null!;

    public string? Nombre { get; set; }
}
